
  # Design Brief for Bixo

  This is a code bundle for Design Brief for Bixo. The original project is available at https://www.figma.com/design/G9csU6dUq49bH5mArH54uJ/Design-Brief-for-Bixo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  